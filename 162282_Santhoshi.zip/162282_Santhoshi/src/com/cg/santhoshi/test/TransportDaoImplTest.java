package com.cg.santhoshi.test;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.santhoshi.bean.TransportBean;
import com.cg.santhoshi.dao.ITransportDao;
import com.cg.santhoshi.dao.TransportDaoImpl;
import com.cg.santhoshi.exception.TransportException;

public class TransportDaoImplTest {

	private static ITransportDao dao = null;

	@BeforeClass
	public static void createInstance() {
		dao = new TransportDaoImpl();
	}

	@Test
	public void testaddTransportDetails() throws TransportException {

		TransportBean bean = new TransportBean();
		bean.setId(8);
		bean.setReason("bhzd");
		bean.setTransportCategoryId("vgf vbn");
		bean.setWhen("This day");
		dao.addTransport(bean);

	}

	@Test
	public void testGetTransportDetails() throws TransportException {

		TransportBean bean = new TransportBean();

		bean.setId(8);
		bean.setReason("bhzd");
		bean.setTransportCategoryId("vgf vbn");
		bean.setWhen("This day");
		dao.addTransport(bean);

		dao.getTransportDetails();

	}

}
