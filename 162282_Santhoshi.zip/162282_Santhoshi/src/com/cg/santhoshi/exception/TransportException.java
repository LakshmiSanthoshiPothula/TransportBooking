package com.cg.santhoshi.exception;

public class TransportException extends Exception {

	public TransportException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransportException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
