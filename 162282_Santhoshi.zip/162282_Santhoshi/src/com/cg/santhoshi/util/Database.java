package com.cg.santhoshi.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.santhoshi.bean.TransportBean;

public class Database {

	private static Map<String, String> transportDetails = new HashMap<String, String>();
	private static Map<Integer, TransportBean> bookTransport = new HashMap<Integer, TransportBean>();

	public static Map<String, String> getTransportDetails() {

		transportDetails.put("f-1", "Flight");

		transportDetails.put("t-2", "Train");

		transportDetails.put("ta-1", "Taxi");
		return transportDetails;

	}

	public static void addTransport(TransportBean bean) {
		// TODO Auto-generated method stub

		bookTransport.put(bean.getId(), bean);
	}

}
