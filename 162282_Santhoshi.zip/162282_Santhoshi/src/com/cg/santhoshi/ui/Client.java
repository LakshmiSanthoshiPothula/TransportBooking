package com.cg.santhoshi.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;

import com.cg.santhoshi.bean.TransportBean;
import com.cg.santhoshi.exception.TransportException;
import com.cg.santhoshi.service.ITransportService;
import com.cg.santhoshi.service.TransportServiceImpl;

public class Client {

	public static void main(String[] args) {
		
		
		try{
		TransportBean bean=new TransportBean();
		ITransportService service=new TransportServiceImpl();
		Map<String, String> transportDetails=service.getTransportDetails();
		
		
		System.out.println("MOT");
		int count=1;
		for (Map.Entry<String,String> entryset :transportDetails.entrySet() ) {
			System.out.println(count+". "+entryset.getValue());
			count++;
			
		}
		System.out.println("Enter option");
		@SuppressWarnings("resource")
		Scanner scanner= new Scanner(System.in);
		int choice=scanner.nextInt();
		
		
        int count1=1;
		for (Map.Entry<String,String> entryset :transportDetails.entrySet() ) {
           if(choice==count1){
        	  bean.setTransportCategoryId( entryset.getKey());
           }
			count1++;
	 }
		
		
		
	int id=(int) ((Math.random())*10000);	
	bean.setId(id);
	System.out.println("enter reason");
	scanner.nextLine();
	String reason=scanner.nextLine();
	bean.setReason(reason);
	System.out.println("When\n1.This week\n2.next week\n3.next Month");
	int whenChoice=scanner.nextInt();
	if(whenChoice==1){
		bean.setWhen("This week");
		
	}
	if(whenChoice==2){
		bean.setWhen("Next week");
		
	}
		
	if(whenChoice==3){
		bean.setWhen("next month");
	}
	
	System.out.println(bean);
	service.addTransport(bean);
	
	LocalDateTime ldt=LocalDateTime.now();
	DateTimeFormatter f=DateTimeFormatter.ofPattern("dd MMMM YYYY hh:mm a");
	System.out.println("booked With "+bean.getId()+" on "+ldt.format(f));
	
		}catch(TransportException transportException){
			System.out.println("Error in fetching details and adding");
		}catch(Exception exception){
			System.out.println("Internal error try later");
		}
		
	}
}
